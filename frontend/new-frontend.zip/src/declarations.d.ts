// frontend/src/declarations.d.ts
declare module '*.jpg' {
  const value: any;
  export default value;
}