// frontend/src/pages/Admin/CreateEmployee.tsx
import EmployeeForm from '../../components/admin/EmployeeForm';

const CreateEmployee = () => {
  return <EmployeeForm />;
};

export default CreateEmployee;