import { motion } from 'framer-motion';
import { Box } from '@mui/material';

export const MotionBox = motion(Box);